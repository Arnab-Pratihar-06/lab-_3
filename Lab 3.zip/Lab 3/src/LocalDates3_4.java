import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class LocalDates3_4 
{
	public static void main(String[] args) 
	{
		LocalDate myday1=LocalDate.of(2013, Month.JANUARY,4);
		LocalDate myday2=LocalDate.of(2015, Month.JANUARY,4);
		
		Period p=Period.between(myday2, myday1);
		System.out.println("Year "+p.getYears()+" Months "+p.getMonths()+" Days "+p.getDays());
	}
}
