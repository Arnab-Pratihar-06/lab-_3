import java.util.Scanner;

public class PositiveString 
{
	public static Boolean charArray(String str)
	{
		char ch[] =str.toCharArray();
		char previous ='\u0000';
		for(char current :ch)
		{
			if(current<previous)
			{
				return false;
			}
			previous=current;
		}
		return true;
	}

	public static void main(String[] args) 
	{
		String st=null;
		System.out.println("Enter a string: ");
		Scanner sc=new Scanner(System.in);
		st=sc.next();
		if(charArray(st)==true)
			System.out.println("Positive");
		else
			System.out.println("Negative");
	}
}
