import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;

public class WarrantyExpiry3_5
{
	public static void main(String args[])
	{
		LocalDate date=LocalDate.of(2018, Month.JUNE, 4);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Year & Months Of warranty");
		int years=sc.nextInt();
		int months=sc.nextInt();
		Warranty(date,years,months);
		
	}

	public static void Warranty(LocalDate date,int years,int months)
	{
		date=date.plusYears(years);
		date=date.plusMonths(months);
		System.out.println(date);
		
		
	}
}
