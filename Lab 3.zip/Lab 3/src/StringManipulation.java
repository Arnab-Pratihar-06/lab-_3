import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class StringManipulation 
{	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String str=sc.next();
		System.out.println("Enter 1 to ADD String");
		System.out.println("Enter 2 to REPLACE odd positions with #");
		System.out.println("Enter 3 for removing duplicate characters ");
		System.out.println("Enter 4 for changing odd characters to upper case ");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:addString(str);break;
		case 2:replace(str);break;
		case 3:Duplicate(str);break;
		case 4:oddToUpper(str);break;
		default: System.out.println("Wrong Choice!");
		}
	}
	public static void Duplicate(String str)
	{
		char[] chars=str.toCharArray();
		Set<Character>charSet=new LinkedHashSet<Character>();
		for(char c:chars)
		{
			charSet.add(c);
			StringBuilder sb=new StringBuilder();
			for(Character character :charSet)
			{
				sb.append(character);
			}
			System.out.println(sb.toString());
		}
	}
	public static void replace(String str)
	{
		for(int i=0;i<=str.length();i++)
		{
			if(i%2!=0)
			{
				str=str.substring(0,i-1)+"#"+str.substring(i,str.length());
			}
		}
		System.out.println(str);
	}

	public static void addString(String str)
	{
		str=str.concat(str);
		System.out.println(str);
	}
	public static void oddToUpper(String str)
	{
		char ch[]=str.toCharArray();
		for(int i=0;i<str.length();i=i+2)
		{
			ch[i]=(char)(ch[i]-'a'+'A');
		}
		System.out.println(ch);
	}
}
				
