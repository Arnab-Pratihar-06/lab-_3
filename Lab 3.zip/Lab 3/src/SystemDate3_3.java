import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class SystemDate3_3 
{
	public static void inBetween(LocalDate myday, LocalDate today)
	{
		Period p=Period.between(myday, today);
		System.out.println("Year " + p.getYears() + " Months "+p.getMonths()+ " Days" + p.getDays());
	}

	public static void main(String[] args) 
	{
		LocalDate today=LocalDate.now();
		LocalDate myday=LocalDate.of(2015, Month.JANUARY, 4);
		inBetween(myday,today);
	}
}
