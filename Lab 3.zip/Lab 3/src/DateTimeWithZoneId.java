
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.TimeZone;

public class DateTimeWithZoneId 
{
	public static void printTime(String str)
	{
		Date today=new Date();
		DateFormat df=new SimpleDateFormat("dd-MM-YY HH:mm:ss");
		df.setTimeZone(TimeZone.getTimeZone(str));
		String Ist=df.format(today);
		System.out.println("Date in TimeZone: "+Ist);
	}
	
	public static void main(String[] args) 
	{
		System.out.println("Enter time zone Id: ");
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		printTime(str);
	}
}